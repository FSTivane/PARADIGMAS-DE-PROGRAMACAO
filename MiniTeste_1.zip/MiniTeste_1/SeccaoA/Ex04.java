import java.io.*;
import java.io.InputStreamReader;
public class Ex04 {
	public static void main(String[] args) throws Exception{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int numFuncionario;
		int numHorasTrabalhadas;
		double valorHora;
		double salario;
		
		System.out.print("Digite o numero do funcionario: ");
		numFuncionario = Integer.parseInt(br.readLine());
		System.out.print("Digite o numero de horas trabalhadas: ");
		numHorasTrabalhadas = Integer.parseInt(br.readLine());
		System.out.print("Digite o valor por hora trabalhada: ");
		valorHora = Double.parseDouble(br.readLine());
		salario = valorHora * numHorasTrabalhadas;
		
		System.out.println("");
		System.out.printf("Numero Funcionario: %d \nSalario: %.2f MZM\n",numFuncionario, salario);
	}
}
